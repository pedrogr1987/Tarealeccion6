/**Clase Romero
 * Propósito: Implementar la interfaz Planta.
 * Autor: Pedro García Rodríguez
 * Fecha: 26/04/2024
 * */
package tarea.paquete;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Romero implements Planta {
	@Autowired
	@Qualifier("bosque")
	private Habitat habitatespecie;

	@Override
	public String getFamilia() {
		// TODO Auto-generated method stub
		return "Labiatae";
	}

	@Override
	public String getEspecie() {
		// TODO Auto-generated method stub
		return "Salvia rosmarinus";
	}

	@Override
	public String getHabitat() {
		// TODO Auto-generated method stub
		return habitatespecie.getHabitat();
	}

}
