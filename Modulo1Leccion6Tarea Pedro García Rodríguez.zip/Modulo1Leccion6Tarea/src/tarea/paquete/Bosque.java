/**Clase Bosque
 * Propósito: Implementar la interfaz Habitat.
 * Autor: Pedro García Rodríguez
 * Fecha: 26/04/2024
 * */
package tarea.paquete;

import org.springframework.stereotype.Component;

@Component
public class Bosque implements Habitat {

	@Override
	public String getHabitat() {
		// TODO Auto-generated method stub
		return "Esta planta se puede encontrar en bosques de todo el país";
	}

}
