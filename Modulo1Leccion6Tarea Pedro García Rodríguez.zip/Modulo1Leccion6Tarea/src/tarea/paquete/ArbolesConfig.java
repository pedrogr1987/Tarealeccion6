/**Clase AnimalesConfig
 * Propósito: Configurar beans a través de un archivo externo.
 * Autor: Pedro García Rodríguez
 * Fecha: 26/04/2024
 * */
package tarea.paquete;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan("tarea.paquete")
@PropertySource("classpath:informacionPino.formato")
public class ArbolesConfig {
	//definir el bean para InformeFinancieroDepCompras
	@Bean
	public Habitat pinaresdecosta() { //esto es el bean inyectado abajo
		return new Pinares();
	}
	
	//definir el bean para Director financiero e inyectar dependencias
	@Bean
	public Planta pino() {
		return new Pino(pinaresdecosta());
	}
}


