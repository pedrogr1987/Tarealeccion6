/**Clase Planta
 * Propósito: interfaz para la creacion de distintas clases
 * Autor: Pedro García Rodríguez
 * Fecha: 26/04/2024
 * */
package tarea.paquete;

public interface Planta {
	public String getFamilia();
	public String getEspecie();
	public String getHabitat();

}
