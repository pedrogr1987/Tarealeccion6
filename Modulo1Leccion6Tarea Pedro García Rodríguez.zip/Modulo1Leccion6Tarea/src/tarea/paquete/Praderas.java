/**Clase Praderas
 * Propósito: Implementar la interfaz Habitat.
 * Autor: Pedro García Rodríguez
 * Fecha: 26/04/2024
 * */
package tarea.paquete;

import org.springframework.stereotype.Component;

@Component
public class Praderas implements Habitat {

	@Override
	public String getHabitat() {
		// TODO Auto-generated method stub
		return "Esta planta se puede encontrar en praderas de todo el país";
	}

}
