/**Clase Principal
 * Propósito: clase main, crear objetos, llamar a los métodos.
 * Autor: Pedro García Rodríguez
 * Fecha: 26/04/2024
 * */
package tarea.paquete;

import java.util.Scanner;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import tarea.paquete.ArbolesConfig;
import tarea.paquete.Romero;
import tarea.paquete.Avena;
import tarea.paquete.Salicornia;
import tarea.paquete.Arnica;


public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Lo primero que hace es leer el xml de configuración. Los beans los vamos a inyectar desde las clases en lugar de usar el xml para crearlos
		ClassPathXmlApplicationContext contexto = new ClassPathXmlApplicationContext("applicationContext.xml");
		//Tambien importamos la configuracion desde ArbolesConfig.class, otra forma de hacerlo sin depender de un xml
		AnnotationConfigApplicationContext contexto2 = new AnnotationConfigApplicationContext(ArbolesConfig.class);

		/*Se pide un Bean al contenedor. Aquí he creado esta interfaz por la consola que pide elegir entre una serie de especies, lo que cambiará de forma 
		automática el bean elegido*/
		System.out.println("Elija la planta de la que desea recibir información sobre familia, especie y habitat: Romero, avena, salicornia o arnica" );
		Scanner sc = new Scanner(System.in);
		String respuesta = sc.next();
		if(respuesta.equals("Romero") ||respuesta.equals("Romero")) {
			 respuesta = "romero";
		}
		else if(respuesta.equals("Avena") ||respuesta.equals("Avena")) {
			 respuesta = "avena";
		}
		else if(respuesta.equals("Salicornia") ||respuesta.equals("salicornia")) {
			 respuesta = "salicornia";
		}
		else if(respuesta.equals("Arnica") ||respuesta.equals("arnica")) {
			 respuesta = "arnica";
		}
		else {
			System.out.println("Opción no válida, se mostrará información por defecto de la planta romero");
			 respuesta = "romero";
		}
		
		Planta Plantaidentificar= contexto.getBean(respuesta,Planta.class);

		//Usamos el bean
		System.out.println("La planta pertenece a la familia " + Plantaidentificar.getFamilia() + " y es de la especie " + Plantaidentificar.getEspecie());
		System.out.println(Plantaidentificar.getHabitat());

		Planta pinito = contexto2.getBean("pino", Planta.class);
		System.out.println("Es común encontrar esta planta junto con ejemplares de " + pinito.getEspecie() + ", perteneciente a la familia " + pinito.getFamilia());
		System.out.println(pinito.getHabitat());
		//IoD por archivo externo (datosEmpresa.propiedades)
		Pino pinito2 = contexto2.getBean("pino", Pino.class);
		System.out.println("Altura: "+ pinito2.getAltura());
		System.out.println("Clase: " + pinito2.getTipo());;

		
		contexto.close();
		contexto2.close();
	}

}
