/**Clase Arnica
 * Propósito: Implementar la interfaz Planta.
 * Autor: Pedro García Rodríguez
 * Fecha: 26/04/2024
 * */
package tarea.paquete;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
@Component
public class Arnica implements Planta {
	@Autowired
	@Qualifier("montana")
	private Habitat habitatespecie;

	@Override
	public String getFamilia() {
		// TODO Auto-generated method stub
		return "Asteracea";
	}

	@Override
	public String getEspecie() {
		// TODO Auto-generated method stub
		return "Arnica montana";
	}

	@Override
	public String getHabitat() {
		// TODO Auto-generated method stub
		return habitatespecie.getHabitat();
	}

}
