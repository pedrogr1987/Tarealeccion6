/**Clase Pino
 * Propósito: Implementar la interfaz Planta. Practicar la IoC y el uso de archivos externos no XML
 * Autor: Pedro García Rodríguez
 * Fecha: 26/04/2024
 * */
package tarea.paquete;

import org.springframework.beans.factory.annotation.Value;
import tarea.paquete.Planta;

public class Pino implements Planta {
	private Habitat pinares;
	@Value("${altura}")
	private String altura;
	@Value("${tipo}")
	private String tipo;
	
	public Pino(Habitat pinar) {
		this.pinares = pinar;
	}
	
	public String getAltura() {
		return altura;
	}

	public String getTipo() {
		return tipo;
	}

	@Override
	public String getFamilia() {
		// TODO Auto-generated method stub
		return "Coniferae";
	}

	@Override
	public String getEspecie() {
		// TODO Auto-generated method stub
		return "Pinus pinea";
	}

	@Override
	public String getHabitat() {
		// TODO Auto-generated method stub
		return pinares.getHabitat();
	}

}