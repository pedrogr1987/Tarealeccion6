/**Interfaz Habitat
 * Propósito: Interfaz para implementarse en distintas clases.
 * Autor: Pedro García Rodríguez
 * Fecha: 26/04/2024
 * */
package tarea.paquete;

public interface Habitat {
	public String getHabitat();

}
