/**Clase Salicornia
 * Propósito: Implementar la interfaz Planta.
 * Autor: Pedro García Rodríguez
 * Fecha: 26/04/2024
 * */
package tarea.paquete;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
@Component
public class Salicornia implements Planta {

	@Autowired
	@Qualifier("costa")
	private Habitat habitatespecie;
	@Override
	public String getFamilia() {
		// TODO Auto-generated method stub
		return "Amarantacea";
	}

	@Override
	public String getEspecie() {
		// TODO Auto-generated method stub
		return "Salicornia Europaea";
	}

	@Override
	public String getHabitat() {
		// TODO Auto-generated method stub
		return habitatespecie.getHabitat();
	}

}
