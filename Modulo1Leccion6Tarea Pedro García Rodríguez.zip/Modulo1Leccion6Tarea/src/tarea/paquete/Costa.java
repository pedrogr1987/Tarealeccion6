/**Clase Costa
 * Propósito: Implementar la interfaz Habitat.
 * Autor: Pedro García Rodríguez
 * Fecha: 26/04/2024
 * */
package tarea.paquete;

import org.springframework.stereotype.Component;

@Component
public class Costa implements Habitat {

	@Override
	public String getHabitat() {
		// TODO Auto-generated method stub
		return "Esta planta se puede encontrar en la costa de todo el país";
	}

}
