/**Clase Pinares
 * Propósito: Implementar la interfaz Habitat.
 * Autor: Pedro García Rodríguez
 * Fecha: 26/04/2024
 * */
package tarea.paquete;

public class Pinares implements Habitat {

	@Override
	public String getHabitat() {
		// TODO Auto-generated method stub
		return "Suelen encontrarse en diversas localizaciones de todo el país, tanto en interior, montaña como cerca de la costa";
	}

}
